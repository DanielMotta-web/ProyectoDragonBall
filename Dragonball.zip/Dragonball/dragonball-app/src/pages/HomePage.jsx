import React, { useEffect, useState } from 'react';
import { getCharacters } from '../api';
import '../App.css';

const HomePage = () => {
  const [characters, setCharacters] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCharacters = async () => {
      try {
        const data = await getCharacters();
        setCharacters(data); // Asigna los items devueltos directamente a characters
      } catch (error) {
        setError('Failed to load characters. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchCharacters();
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div className="character-grid">
      {characters.map(character => (
        <div key={character.id} className="character-card">
          <img className="character-image" src={character.image} alt={character.name} />
          <h2 className="character-name">{character.name}</h2>
          <a className="character-link" href={`/character/${character.id}`}>Ver Detalles</a>
        </div>
      ))}
    </div>
  );
}

export default HomePage;