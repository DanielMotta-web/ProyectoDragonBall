import React from 'react';

function AboutPage() {
  return (
    <div>
      <h1>Acerca de</h1>
      <p>Esta es una aplicación que muestra personajes de Dragon Ball.</p>
      <p>Hecho por José Daniel Motta Rivera del Curso de Web 2.</p>
    </div>
  );
}

export default AboutPage;