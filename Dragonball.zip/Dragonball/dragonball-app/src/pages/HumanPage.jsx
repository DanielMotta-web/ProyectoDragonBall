
import React, { useEffect, useState } from 'react';
import { getCharacters } from '../api';
import CharacterCard from '../components/CharacterCard';

function HumansPage() {
  const [characters, setCharacters] = useState([]);

  useEffect(() => {
    const fetchCharacters = async () => {
      const data = await getCharacters();
      const humanCharacters = data.filter(character => character.race === "Human");
      setCharacters(humanCharacters);
    };
    fetchCharacters();
  }, []);

  return (
    <div 
      style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', // Ajusta el ancho de las columnas
        gap: '16px', // Espacio entre las cards
        padding: '16px', // Margen dentro del contenedor
        justifyContent: 'center', // Centra las cards
      }}
    >
      {characters.map(character => (
        <CharacterCard key={character.id} character={character} />
      ))}
    </div>
  );
}

export default HumansPage;
