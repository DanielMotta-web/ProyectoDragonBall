import axios from 'axios';

const BASE_URL = 'https://dragonball-api.com/api/characters';

export const getCharacters = async () => {
  try {
    const response = await axios.get(BASE_URL);
    return response.data.items;
  } catch (error) {
    console.error('Error fetching characters:', error);
    throw error;
  }
};

// Asegúrate de que getCharacterById también usa la URL correcta
export const getCharacterById = async (id) => {
  try {
    const response = await axios.get(`${BASE_URL}/${id}`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching character with id ${id}:`, error);
    throw error;
  }
};