// CharacterCard.jsx
import React from 'react';
import { Card, CardContent, CardMedia, Typography, Button } from '@mui/material';
import { Link } from 'react-router-dom';

function CharacterCard({ character }) {
  return (
    <Card 
      sx={{
        maxWidth: 200, // Limita el ancho máximo del card para pantallas pequeñas
        margin: 'auto', // Centra el card en su contenedor
        textAlign: 'center',
        backgroundColor: '#1a1a1a',
        color: 'white',
        borderRadius: '8px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
        transition: 'transform 0.2s ease',
        '&:hover': {
          transform: 'scale(1.05)', // Efecto de hover para el card
        },
      }}
    >
      <CardMedia 
        component="img" 
        height="140" 
        image={character.image} 
        alt={character.name} 
        sx={{
          objectFit: 'cover',
          borderRadius: '50%', // Hace la imagen circular
          width: '80%', // Ajusta el tamaño de la imagen dentro del CardMedia
          height: 'auto',
          margin: '16px auto', // Centra la imagen con espacio alrededor
        }}
      />
      <CardContent>
        <Typography 
          gutterBottom 
          variant="h5" 
          component="div"
          sx={{ fontSize: '1.2em' }} // Ajusta el tamaño del texto
        >
          {character.name}
        </Typography>
        <Button 
          component={Link} 
          to={`/character/${character.id}`} 
          sx={{
            color: '#1e90ff',
            fontWeight: 'bold',
            '&:hover': {
              textDecoration: 'underline',
            },
          }}
        >
          Ver Detalles
        </Button>
      </CardContent>
    </Card>
  );
}

export default CharacterCard;
